﻿namespace Arsch_mit_Ohren
{
    partial class FrmArsch
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmArsch));
            this.DlgDateiauswahl = new System.Windows.Forms.OpenFileDialog();
            this.DlgSchlusselauswahl = new System.Windows.Forms.OpenFileDialog();
            this.PnlVerschlusseln = new System.Windows.Forms.GroupBox();
            this.BtnErzeugen = new System.Windows.Forms.Button();
            this.LblVerschlusseln = new System.Windows.Forms.Label();
            this.LblSchlussel = new System.Windows.Forms.Label();
            this.LblQuelldatei = new System.Windows.Forms.Label();
            this.BtnVerschlusseln = new System.Windows.Forms.Button();
            this.BtnSchlusselauswahl = new System.Windows.Forms.Button();
            this.BtnDateiauswahl = new System.Windows.Forms.Button();
            this.BtnHilfe = new System.Windows.Forms.Button();
            this.BtnInfo = new System.Windows.Forms.Button();
            this.DlgZielauswahl = new System.Windows.Forms.SaveFileDialog();
            this.PnlVerschlusseln.SuspendLayout();
            this.SuspendLayout();
            // 
            // DlgDateiauswahl
            // 
            this.DlgDateiauswahl.Filter = resources.GetString("DlgDateiauswahl.Filter");
            this.DlgDateiauswahl.Title = "Quelldatei öffnen";
            // 
            // DlgSchlusselauswahl
            // 
            this.DlgSchlusselauswahl.Filter = "Schlüsseldateien (*.key)|*.*key";
            this.DlgSchlusselauswahl.Title = "Schlüsseldatei öffnen";
            // 
            // PnlVerschlusseln
            // 
            this.PnlVerschlusseln.Controls.Add(this.BtnErzeugen);
            this.PnlVerschlusseln.Controls.Add(this.LblVerschlusseln);
            this.PnlVerschlusseln.Controls.Add(this.LblSchlussel);
            this.PnlVerschlusseln.Controls.Add(this.LblQuelldatei);
            this.PnlVerschlusseln.Controls.Add(this.BtnVerschlusseln);
            this.PnlVerschlusseln.Controls.Add(this.BtnSchlusselauswahl);
            this.PnlVerschlusseln.Controls.Add(this.BtnDateiauswahl);
            this.PnlVerschlusseln.Location = new System.Drawing.Point(12, 12);
            this.PnlVerschlusseln.Name = "PnlVerschlusseln";
            this.PnlVerschlusseln.Size = new System.Drawing.Size(656, 277);
            this.PnlVerschlusseln.TabIndex = 2;
            this.PnlVerschlusseln.TabStop = false;
            this.PnlVerschlusseln.Text = "Verschlüsseln/Entschlüsseln";
            // 
            // BtnErzeugen
            // 
            this.BtnErzeugen.Location = new System.Drawing.Point(16, 30);
            this.BtnErzeugen.Name = "BtnErzeugen";
            this.BtnErzeugen.Size = new System.Drawing.Size(296, 36);
            this.BtnErzeugen.TabIndex = 0;
            this.BtnErzeugen.Text = "&0.: Schlüsseldatei erzeugen";
            this.BtnErzeugen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnErzeugen.UseVisualStyleBackColor = true;
            this.BtnErzeugen.Click += new System.EventHandler(this.BtnErzeugen_Click);
            // 
            // LblVerschlusseln
            // 
            this.LblVerschlusseln.Location = new System.Drawing.Point(340, 217);
            this.LblVerschlusseln.Name = "LblVerschlusseln";
            this.LblVerschlusseln.Size = new System.Drawing.Size(299, 36);
            this.LblVerschlusseln.TabIndex = 7;
            // 
            // LblSchlussel
            // 
            this.LblSchlussel.Location = new System.Drawing.Point(340, 162);
            this.LblSchlussel.Name = "LblSchlussel";
            this.LblSchlussel.Size = new System.Drawing.Size(299, 36);
            this.LblSchlussel.TabIndex = 6;
            // 
            // LblQuelldatei
            // 
            this.LblQuelldatei.Location = new System.Drawing.Point(340, 107);
            this.LblQuelldatei.Name = "LblQuelldatei";
            this.LblQuelldatei.Size = new System.Drawing.Size(299, 36);
            this.LblQuelldatei.TabIndex = 5;
            // 
            // BtnVerschlusseln
            // 
            this.BtnVerschlusseln.Enabled = false;
            this.BtnVerschlusseln.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVerschlusseln.Location = new System.Drawing.Point(16, 217);
            this.BtnVerschlusseln.Name = "BtnVerschlusseln";
            this.BtnVerschlusseln.Size = new System.Drawing.Size(296, 36);
            this.BtnVerschlusseln.TabIndex = 3;
            this.BtnVerschlusseln.Text = "&3.: Schlüsseloperation durchführen";
            this.BtnVerschlusseln.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnVerschlusseln.UseVisualStyleBackColor = true;
            this.BtnVerschlusseln.Click += new System.EventHandler(this.BtnVerschlusseln_Click);
            // 
            // BtnSchlusselauswahl
            // 
            this.BtnSchlusselauswahl.Enabled = false;
            this.BtnSchlusselauswahl.Location = new System.Drawing.Point(16, 162);
            this.BtnSchlusselauswahl.Name = "BtnSchlusselauswahl";
            this.BtnSchlusselauswahl.Size = new System.Drawing.Size(296, 36);
            this.BtnSchlusselauswahl.TabIndex = 2;
            this.BtnSchlusselauswahl.Text = "&2.: Schlüssel auswählen";
            this.BtnSchlusselauswahl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSchlusselauswahl.UseVisualStyleBackColor = true;
            this.BtnSchlusselauswahl.Click += new System.EventHandler(this.BtnSchlusselauswahl_Click);
            // 
            // BtnDateiauswahl
            // 
            this.BtnDateiauswahl.Location = new System.Drawing.Point(16, 107);
            this.BtnDateiauswahl.Name = "BtnDateiauswahl";
            this.BtnDateiauswahl.Size = new System.Drawing.Size(296, 36);
            this.BtnDateiauswahl.TabIndex = 1;
            this.BtnDateiauswahl.Text = "&1.: Dateiauswahl";
            this.BtnDateiauswahl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDateiauswahl.UseVisualStyleBackColor = true;
            this.BtnDateiauswahl.Click += new System.EventHandler(this.BtnDateiauswahl_Click);
            // 
            // BtnHilfe
            // 
            this.BtnHilfe.Location = new System.Drawing.Point(28, 314);
            this.BtnHilfe.Name = "BtnHilfe";
            this.BtnHilfe.Size = new System.Drawing.Size(296, 36);
            this.BtnHilfe.TabIndex = 4;
            this.BtnHilfe.Text = "&Hilfe";
            this.BtnHilfe.UseVisualStyleBackColor = true;
            this.BtnHilfe.Click += new System.EventHandler(this.BtnHilfe_Click);
            // 
            // BtnInfo
            // 
            this.BtnInfo.Location = new System.Drawing.Point(355, 314);
            this.BtnInfo.Name = "BtnInfo";
            this.BtnInfo.Size = new System.Drawing.Size(296, 36);
            this.BtnInfo.TabIndex = 5;
            this.BtnInfo.Text = "&Info";
            this.BtnInfo.UseVisualStyleBackColor = true;
            this.BtnInfo.Click += new System.EventHandler(this.BtnInfo_Click);
            // 
            // DlgZielauswahl
            // 
            this.DlgZielauswahl.AddExtension = false;
            this.DlgZielauswahl.Filter = "Alle Dateien (*.*)|*.*";
            this.DlgZielauswahl.Title = "Zieldatei eingeben";
            // 
            // FrmArsch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 378);
            this.Controls.Add(this.PnlVerschlusseln);
            this.Controls.Add(this.BtnHilfe);
            this.Controls.Add(this.BtnInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmArsch";
            this.Text = "Arsch mit Ohren";
            this.PnlVerschlusseln.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog DlgDateiauswahl;
        private System.Windows.Forms.OpenFileDialog DlgSchlusselauswahl;
        private System.Windows.Forms.GroupBox PnlVerschlusseln;
        private System.Windows.Forms.Button BtnSchlusselauswahl;
        private System.Windows.Forms.Button BtnDateiauswahl;
        private System.Windows.Forms.Button BtnVerschlusseln;
        private System.Windows.Forms.Label LblQuelldatei;
        private System.Windows.Forms.Label LblSchlussel;
        private System.Windows.Forms.Label LblVerschlusseln;
        private System.Windows.Forms.SaveFileDialog DlgZielauswahl;
        private System.Windows.Forms.Button BtnInfo;
        private System.Windows.Forms.Button BtnHilfe;
        private System.Windows.Forms.Button BtnErzeugen;

    }
}

