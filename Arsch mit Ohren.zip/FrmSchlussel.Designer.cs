﻿namespace Arsch_mit_Ohren
{
    partial class FrmSchlussel
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.DlgSpeichern = new System.Windows.Forms.SaveFileDialog();
            this.LblGrose = new System.Windows.Forms.Label();
            this.SpnGrose = new System.Windows.Forms.NumericUpDown();
            this.BtnErzeugen = new System.Windows.Forms.Button();
            this.BtnSchliesen = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SpnGrose)).BeginInit();
            this.SuspendLayout();
            // 
            // DlgSpeichern
            // 
            this.DlgSpeichern.Filter = "Schlüsseldateien (*.key)|*.key";
            this.DlgSpeichern.Title = "Schlüsseldatei speichern";
            // 
            // LblGrose
            // 
            this.LblGrose.Location = new System.Drawing.Point(23, 17);
            this.LblGrose.Name = "LblGrose";
            this.LblGrose.Size = new System.Drawing.Size(223, 20);
            this.LblGrose.TabIndex = 0;
            this.LblGrose.Text = "Größe der Schlüsseldatei in 1 MB-Blöcken:";
            this.LblGrose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SpnGrose
            // 
            this.SpnGrose.Location = new System.Drawing.Point(252, 17);
            this.SpnGrose.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SpnGrose.Name = "SpnGrose";
            this.SpnGrose.Size = new System.Drawing.Size(92, 20);
            this.SpnGrose.TabIndex = 0;
            this.SpnGrose.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // BtnErzeugen
            // 
            this.BtnErzeugen.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnErzeugen.Location = new System.Drawing.Point(23, 67);
            this.BtnErzeugen.Name = "BtnErzeugen";
            this.BtnErzeugen.Size = new System.Drawing.Size(321, 36);
            this.BtnErzeugen.TabIndex = 1;
            this.BtnErzeugen.Text = "Schlüsseldatei erzeugen";
            this.BtnErzeugen.UseVisualStyleBackColor = true;
            this.BtnErzeugen.Click += new System.EventHandler(this.BtnErzeugen_Click);
            // 
            // BtnSchliesen
            // 
            this.BtnSchliesen.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnSchliesen.Location = new System.Drawing.Point(23, 131);
            this.BtnSchliesen.Name = "BtnSchliesen";
            this.BtnSchliesen.Size = new System.Drawing.Size(321, 36);
            this.BtnSchliesen.TabIndex = 2;
            this.BtnSchliesen.Text = "Schließen";
            this.BtnSchliesen.UseVisualStyleBackColor = true;
            this.BtnSchliesen.Click += new System.EventHandler(this.BtnSchliesen_Click);
            // 
            // FrmSchlussel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 198);
            this.ControlBox = false;
            this.Controls.Add(this.BtnSchliesen);
            this.Controls.Add(this.BtnErzeugen);
            this.Controls.Add(this.SpnGrose);
            this.Controls.Add(this.LblGrose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSchlussel";
            this.ShowInTaskbar = false;
            this.Text = "Schlüsseldatei erzeugen";
            ((System.ComponentModel.ISupportInitialize)(this.SpnGrose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog DlgSpeichern;
        private System.Windows.Forms.Label LblGrose;
        private System.Windows.Forms.NumericUpDown SpnGrose;
        private System.Windows.Forms.Button BtnErzeugen;
        private System.Windows.Forms.Button BtnSchliesen;
    }
}