﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Arsch_mit_Ohren
{
    public partial class FrmArsch : Form
    {
        String QuellDatei;
        String SchlusselDatei;
        String ZielDatei;
                        
        public FrmArsch()
        {
            InitializeComponent();
        }

        private void BtnDateiauswahl_Click(object sender, EventArgs e)
        {
            DialogResult Eingabe;

            Eingabe = DlgDateiauswahl.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                QuellDatei = DlgDateiauswahl.FileName;
                LblQuelldatei.Text = DlgDateiauswahl.FileName;
                BtnSchlusselauswahl.Enabled = true;
            }
        }

        private void BtnSchlusselauswahl_Click(object sender, EventArgs e)
        {
            DialogResult Eingabe;

            Eingabe = DlgSchlusselauswahl.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                SchlusselDatei = DlgSchlusselauswahl.FileName;
                LblSchlussel.Text = DlgSchlusselauswahl.FileName;
                BtnVerschlusseln.Enabled = true;
            }
        }

        private void BtnVerschlusseln_Click(object sender, EventArgs e)
        {
            DialogResult Eingabe;
            FileStream Quelle;
            FileStream Schlussel;
            FileStream Ziel;
            int ByteIndex;
            int ReadOut;
            byte Auslesewert;
            byte Schlusselwert;
            byte Schreibwert;
            
            Eingabe = DlgZielauswahl.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                ZielDatei = DlgZielauswahl.FileName;
                LblVerschlusseln.Text = ZielDatei;
                if (QuellDatei == ZielDatei)
                {
                    Eingabe = MessageBox.Show("Die Quelldatei und die Zieldatei sind identisch. Dann kann die Operation nicht durchgeführt werden.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    Quelle = File.Open(QuellDatei, FileMode.Open, FileAccess.Read, FileShare.None);
                    Schlussel = File.Open(SchlusselDatei, FileMode.Open, FileAccess.Read, FileShare.None);
                    Ziel = File.Create(ZielDatei);
                    for (ByteIndex = 0; ByteIndex < Quelle.Length; ByteIndex = ByteIndex + 1)
                    {
                        Auslesewert = Convert.ToByte(Quelle.ReadByte());
                        ReadOut = Schlussel.ReadByte();
                        /*Wenn ReadByte eine -1 zurückgibt, dann ist die Schlüsseldatei zu Ende.*/
                        if (ReadOut < 0)
                        {
                            Schlussel.Seek(0, SeekOrigin.Begin);
                            ReadOut = Schlussel.ReadByte();
                            Schlusselwert = Convert.ToByte(ReadOut);
                        }
                        Schlusselwert = Convert.ToByte(ReadOut);
                        Schreibwert = Convert.ToByte(Auslesewert ^ Schlusselwert);
                        Ziel.WriteByte(Schreibwert);
                    }
                    Quelle.Dispose();
                    Schlussel.Dispose();
                    Ziel.Dispose();
                }
            }
        }

        private void BtnInfo_Click(object sender, EventArgs e)
        {
            new FrmInfo().ShowDialog();
        }

        private void BtnHilfe_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this,"Arsch mit Ohren.chm");
        }

        private void BtnErzeugen_Click(object sender, EventArgs e)
        {
            new FrmSchlussel().ShowDialog();
        }
    }
}
