﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Arsch_mit_Ohren
{
    public partial class FrmSchlussel : Form
    {
        public FrmSchlussel()
        {
            InitializeComponent();
        }

        private void BtnSchliesen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnErzeugen_Click(object sender, EventArgs e)
        {
            Random Zufall = new Random();
            DialogResult Eingabe;
            FileStream Schlussel;
            String SchlusselDatei;
            long BlockIndex;
            long ZahlIndex;
            byte[] Zufallszahl = new Byte[1];
            
            Eingabe = DlgSpeichern.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                SchlusselDatei = DlgSpeichern.FileName;
                Schlussel = File.Create(SchlusselDatei);
                for (BlockIndex = 0; BlockIndex < SpnGrose.Value; BlockIndex = BlockIndex + 1)
                {
                    for (ZahlIndex = 0; ZahlIndex < 1056000; ZahlIndex = ZahlIndex + 1)
                    {
                        Zufall.NextBytes(Zufallszahl);
                        Schlussel.WriteByte(Zufallszahl[0]);
                    }
                }
                Schlussel.Dispose();
            }
            this.Close();
        }
    }
}
