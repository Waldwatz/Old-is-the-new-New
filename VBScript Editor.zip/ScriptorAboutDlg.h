//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptoraboutdlg.h
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TScriptorAboutDlg (TDialog).
//
//----------------------------------------------------------------------------
#if !defined(scriptoraboutdlg_h)              // Sentry, use file only if it's not already included.
#define scriptoraboutdlg_h

#include <owl/static.h>

#include "scriptorapp.rh"                  // Definition of all resources.


//{{TDialog = TScriptorAboutDlg}}
class TScriptorAboutDlg : public TDialog {
  public:
    TScriptorAboutDlg(TWindow* parent, TResId resId = IDD_ABOUT, TModule* module = 0);
    virtual ~TScriptorAboutDlg();

//{{TScriptorAboutDlgVIRTUAL_BEGIN}}
  public:
    void SetupWindow();
//{{TScriptorAboutDlgVIRTUAL_END}}
};    //{{TScriptorAboutDlg}}


// Reading the VERSIONINFO resource.
//
class TProjectRCVersion {
  public:
    TProjectRCVersion(TModule* module);
    virtual ~TProjectRCVersion();

    bool GetProductName(LPSTR& prodName);
    bool GetProductVersion(LPSTR& prodVersion);
    bool GetCopyright(LPSTR& copyright);
    bool GetDebug(LPSTR& debug);

  protected:
    uint8 far*  TransBlock;
    void far*   FVData;

  private:
    // Don't allow this object to be copied.
    //
    TProjectRCVersion(const TProjectRCVersion&);
    TProjectRCVersion& operator = (const TProjectRCVersion&);
};


#endif  // scriptoraboutdlg_h sentry.
