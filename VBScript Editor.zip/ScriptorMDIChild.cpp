//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptormdichild.cpp
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TScriptorMDIChild (TMDIChild).
//
//----------------------------------------------------------------------------

#include <owl/pch.h>

#include "scriptorapp.h"
#include "scriptormdichild.h"


//{{TScriptorMDIChild Implementation}}


//--------------------------------------------------------
// TScriptorMDIChild
// ~~~~~~~~~~
// Construction/Destruction handling.
//
TScriptorMDIChild::TScriptorMDIChild(TMDIClient& parent, const char far* title, TWindow* clientWnd, bool shrinkToClient, TModule* module)
:
  TMDIChild(parent, title, clientWnd, shrinkToClient, module)
{
  // INSERT>> Your constructor code here.

}


TScriptorMDIChild::~TScriptorMDIChild()
{
  Destroy();

  // INSERT>> Your destructor code here.

}
