//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptoreditview.h
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TScriptorEditView (TEditView).
//
//----------------------------------------------------------------------------
#if !defined(scriptoreditview_h)              // Sentry, use file only if it's not already included.
#define scriptoreditview_h

#include <owl/editview.h>

#include "scriptorapp.rh"          // Definition of all resources.


//{{TEditView = TScriptorEditView}}
class TScriptorEditView : public TEditView {
  public:
    TScriptorEditView(TDocument& doc, TWindow* parent = 0);
    virtual ~TScriptorEditView();

//{{TScriptorEditViewVIRTUAL_BEGIN}}
  public:
    virtual void Paint(TDC& dc, bool erase, TRect& rect);
//{{TScriptorEditViewVIRTUAL_END}}
//{{TScriptorEditViewRSP_TBL_BEGIN}}
  protected:
    void EvGetMinMaxInfo(MINMAXINFO far& minmaxinfo);
    void CmExecute();
//{{TScriptorEditViewRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TScriptorEditView);
};    //{{TScriptorEditView}}


#endif  // scriptoreditview_h sentry.
