//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptormdiclient.h
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TScriptorMDIClient (TMDIClient).
//
//----------------------------------------------------------------------------
#if !defined(scriptormdiclient_h)              // Sentry, use file only if it's not already included.
#define scriptormdiclient_h

#include "scriptorapp.rh"            // Definition of all resources.


//{{TMDIClient = TScriptorMDIClient}}
class TScriptorMDIClient : public TMDIClient {
  public:
    int      ChildCount;                 // Number of child window created.

    TScriptorMDIClient(TModule* module = 0);
    virtual ~TScriptorMDIClient();

    void OpenFile(const char* fileName = 0);

//{{TScriptorMDIClientVIRTUAL_BEGIN}}
  protected:
    virtual void SetupWindow();
//{{TScriptorMDIClientVIRTUAL_END}}

//{{TScriptorMDIClientRSP_TBL_BEGIN}}
  protected:
    void CmFilePrint();
    void CmFilePrintSetup();
    void CmFilePrintPreview();
    void CmPrintEnable(TCommandEnabler& tce);
    void EvDropFiles(TDropInfo);
//{{TScriptorMDIClientRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TScriptorMDIClient);
};    //{{TScriptorMDIClient}}


#endif  // scriptormdiclient_h sentry.
