//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptormdichild.h
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TScriptorMDIChild (TMDIChild).
//
//----------------------------------------------------------------------------
#if !defined(scriptormdichild_h)              // Sentry, use file only if it's not already included.
#define scriptormdichild_h

#include "scriptorapp.rh"            // Definition of all resources.


//{{TMDIChild = TScriptorMDIChild}}
class TScriptorMDIChild : public TMDIChild {
  public:
    TScriptorMDIChild(TMDIClient& parent, const char far* title, TWindow* clientWnd, bool shrinkToClient = false, TModule* module = 0);
    virtual ~TScriptorMDIChild();
};    //{{TScriptorMDIChild}}


#endif  // scriptormdichild_h sentry.
