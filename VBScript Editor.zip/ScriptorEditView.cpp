//----------------------------------------------------------------------------
//  Project Scriptor
//  Konstantin Knips Freeware
//  Copyright � 2021. All Rights Reserved.
//
//  SUBSYSTEM:    Scriptor Application
//  FILE:         scriptoreditview.cpp
//  AUTHOR:       Hamwanich
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TScriptorEditView (TEditView).
//
//----------------------------------------------------------------------------

#include <owl/pch.h>

#include "scriptorapp.h"
#include "scriptoreditview.h"

#include <stdio.h>


//{{TScriptorEditView Implementation}}


//
// Build a response table for all messages/commands handled
// by TScriptorEditView derived from TEditView.
//
DEFINE_RESPONSE_TABLE1(TScriptorEditView, TEditView)
//{{TScriptorEditViewRSP_TBL_BEGIN}}
  EV_WM_GETMINMAXINFO,
  EV_COMMAND(CM_EXECUTE, CmExecute),
//{{TScriptorEditViewRSP_TBL_END}}
END_RESPONSE_TABLE;


//--------------------------------------------------------
// TScriptorEditView
// ~~~~~~~~~~
// Construction/Destruction handling.
//
TScriptorEditView::TScriptorEditView(TDocument& doc, TWindow* parent)
:
  TEditView(doc, parent)
{
  // INSERT>> Your constructor code here.

}


TScriptorEditView::~TScriptorEditView()
{
  // INSERT>> Your destructor code here.

}


//
// Paint routine for Window, Printer, and PrintPreview for a TEditView client.
//
void TScriptorEditView::Paint(TDC& dc, bool, TRect& rect)
{
  TScriptorApp* theApp = TYPESAFE_DOWNCAST(GetApplication(), TScriptorApp);
  if (theApp) {
    // Only paint if we're printing and we have something to paint, otherwise do nothing.
    //
    if (theApp->Printing && theApp->Printer && !rect.IsEmpty()) {
      // Use pageSize to get the size of the window to render into.  For a Window it's the client area,
      // for a printer it's the printer DC dimensions and for print preview it's the layout window.
      TSize   pageSize(rect.right - rect.left, rect.bottom - rect.top);

      HFONT   hFont = (HFONT)GetWindowFont();
      TFont   font("Arial", -12);
      if (!hFont)
        dc.SelectObject(font);
      else
        dc.SelectObject(TFont(hFont));

      TEXTMETRIC  tm;
      int fHeight = dc.GetTextMetrics(tm) ? tm.tmHeight + tm.tmExternalLeading : 10;

      // How many lines of this font can we fit on a page.
      //
      int linesPerPage = MulDiv(pageSize.cy, 1, fHeight);
      if (linesPerPage) {
        TPrintDialog::TData& printerData = theApp->Printer->GetSetup();

        int maxPg = ((GetNumLines() / linesPerPage) + 1.0);

        // Compute the number of pages to print.
        //
        printerData.MinPage = 1;
        printerData.MaxPage = maxPg;

        // Do the text stuff:
        //
        int   fromPage = printerData.FromPage == -1 ? 1 : printerData.FromPage;
        int   toPage = printerData.ToPage == -1 ? 1 : printerData.ToPage;
        int   currentPage = fromPage;
        TAPointer<char> buffer = new char[255];

        while (currentPage <= toPage) {
          int startLine = (currentPage - 1) * linesPerPage;
          int lineIdx = 0;
          while (lineIdx < linesPerPage) {
            // If the string is no longer valid then there's nothing more to display.
            //
            if (!GetLine(buffer, 255, startLine + lineIdx))
              break;
            dc.TabbedTextOut(TPoint(0, lineIdx * fHeight), buffer, strlen(buffer), 0, 0, 0);
            lineIdx++;
          }
          currentPage++;
        }
      }
    }
  }
}


void TScriptorEditView::EvGetMinMaxInfo(MINMAXINFO far& minmaxinfo)
{
  TScriptorApp* theApp = TYPESAFE_DOWNCAST(GetApplication(), TScriptorApp);
  if (theApp) {
    if (theApp->Printing) {
      minmaxinfo.ptMaxSize = TPoint(32000, 32000);
      minmaxinfo.ptMaxTrackSize = TPoint(32000, 32000);
      return;
    }
  }
  TEditView::EvGetMinMaxInfo(minmaxinfo);
}

void TScriptorEditView::CmExecute()
{
  HINSTANCE RuckgabeWert;
  TDocument& Quelltext = this->GetDocument();

  if(!this->VnIsDirty()){
    RuckgabeWert = ShellExecute(0, 0, Quelltext.GetDocPath(), 0, 0, SW_SHOWDEFAULT);
    if((int)RuckgabeWert<=32){
  	   MessageBox("There was an error while executing the Visual Basic Script file.", 0, MB_OK|MB_ICONHAND|MB_APPLMODAL);}}
  else{
    MessageBox("Prior to execution, the changes in the source code should be saved.", 0, MB_OK|MB_ICONHAND|MB_APPLMODAL);}
}

