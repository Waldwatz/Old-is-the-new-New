// InflaDlg.h : header file
//

#if !defined(AFX_INFLADLG_H__73906939_EF7C_4888_9A02_3620B738A3B8__INCLUDED_)
#define AFX_INFLADLG_H__73906939_EF7C_4888_9A02_3620B738A3B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CInflaDlg dialog

class CInflaDlg : public CDialog
{
// Construction
public:
	CInflaDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CInflaDlg)
	enum { IDD = IDD_INFLA_DIALOG };
	CListBox	LstErgebnis;
	CEdit	EdtLaufzeit;
	CEdit	EdtInflation;
	CEdit	EdtAnfangskapital;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInflaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CInflaDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void BtnBerechnenClick();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INFLADLG_H__73906939_EF7C_4888_9A02_3620B738A3B8__INCLUDED_)
