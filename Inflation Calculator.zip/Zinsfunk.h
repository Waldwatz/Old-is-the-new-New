#include <math.h>

double ErtragOhneZinseszins(double startKapital, double prozZins, double laufzeit);
double VerlustMitInflation(double startKapital, double Inflation, double laufzeit);