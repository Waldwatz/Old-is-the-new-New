#include "stdafx.h"
#include "Zinsfunk.h"

double ErtragOhneZinseszins(double startKapital, double prozZins, double laufzeit)
{
	return startKapital*(1+prozZins/100.0*laufzeit);
}

double VerlustMitInflation(double startKapital, double Inflation, double laufzeit)
{
	return startKapital*(1-Inflation/100.0*laufzeit);
}