﻿namespace Der_geflügelte_Scheißhaufen
{
    partial class FrmScheishaufen
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmScheishaufen));
            this.PnlScheishaufen = new System.Windows.Forms.GroupBox();
            this.OptEnschlusseln = new System.Windows.Forms.RadioButton();
            this.OptVerschlusseln = new System.Windows.Forms.RadioButton();
            this.LblPaswort = new System.Windows.Forms.Label();
            this.LblZieldatei = new System.Windows.Forms.Label();
            this.LblQuelldatei = new System.Windows.Forms.Label();
            this.BtnZieldatei = new System.Windows.Forms.Button();
            this.BtnPaswort = new System.Windows.Forms.Button();
            this.BtnQuelldatei = new System.Windows.Forms.Button();
            this.DlgQuelldatei = new System.Windows.Forms.OpenFileDialog();
            this.DlgZieldatei = new System.Windows.Forms.SaveFileDialog();
            this.BtnHilfe = new System.Windows.Forms.Button();
            this.BtnInfo = new System.Windows.Forms.Button();
            this.BtnSalat = new System.Windows.Forms.Button();
            this.PnlScheishaufen.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlScheishaufen
            // 
            this.PnlScheishaufen.Controls.Add(this.OptEnschlusseln);
            this.PnlScheishaufen.Controls.Add(this.OptVerschlusseln);
            this.PnlScheishaufen.Controls.Add(this.LblPaswort);
            this.PnlScheishaufen.Controls.Add(this.LblZieldatei);
            this.PnlScheishaufen.Controls.Add(this.LblQuelldatei);
            this.PnlScheishaufen.Controls.Add(this.BtnZieldatei);
            this.PnlScheishaufen.Controls.Add(this.BtnPaswort);
            this.PnlScheishaufen.Controls.Add(this.BtnQuelldatei);
            this.PnlScheishaufen.Location = new System.Drawing.Point(34, 90);
            this.PnlScheishaufen.Name = "PnlScheishaufen";
            this.PnlScheishaufen.Size = new System.Drawing.Size(572, 309);
            this.PnlScheishaufen.TabIndex = 0;
            this.PnlScheishaufen.TabStop = false;
            this.PnlScheishaufen.Text = "Chiffrieroperationen";
            // 
            // OptEnschlusseln
            // 
            this.OptEnschlusseln.AutoSize = true;
            this.OptEnschlusseln.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OptEnschlusseln.Location = new System.Drawing.Point(166, 39);
            this.OptEnschlusseln.Name = "OptEnschlusseln";
            this.OptEnschlusseln.Size = new System.Drawing.Size(89, 17);
            this.OptEnschlusseln.TabIndex = 2;
            this.OptEnschlusseln.Text = "Entschlüsseln";
            this.OptEnschlusseln.UseVisualStyleBackColor = true;
            // 
            // OptVerschlusseln
            // 
            this.OptVerschlusseln.AutoSize = true;
            this.OptVerschlusseln.Checked = true;
            this.OptVerschlusseln.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OptVerschlusseln.Location = new System.Drawing.Point(33, 39);
            this.OptVerschlusseln.Name = "OptVerschlusseln";
            this.OptVerschlusseln.Size = new System.Drawing.Size(89, 17);
            this.OptVerschlusseln.TabIndex = 1;
            this.OptVerschlusseln.TabStop = true;
            this.OptVerschlusseln.Text = "Verschlüsseln";
            this.OptVerschlusseln.UseVisualStyleBackColor = true;
            // 
            // LblPaswort
            // 
            this.LblPaswort.Location = new System.Drawing.Point(304, 157);
            this.LblPaswort.Name = "LblPaswort";
            this.LblPaswort.Size = new System.Drawing.Size(226, 48);
            this.LblPaswort.TabIndex = 5;
            // 
            // LblZieldatei
            // 
            this.LblZieldatei.Location = new System.Drawing.Point(304, 234);
            this.LblZieldatei.Name = "LblZieldatei";
            this.LblZieldatei.Size = new System.Drawing.Size(226, 48);
            this.LblZieldatei.TabIndex = 4;
            // 
            // LblQuelldatei
            // 
            this.LblQuelldatei.Location = new System.Drawing.Point(304, 81);
            this.LblQuelldatei.Name = "LblQuelldatei";
            this.LblQuelldatei.Size = new System.Drawing.Size(226, 48);
            this.LblQuelldatei.TabIndex = 3;
            // 
            // BtnZieldatei
            // 
            this.BtnZieldatei.Enabled = false;
            this.BtnZieldatei.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnZieldatei.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnZieldatei.Location = new System.Drawing.Point(33, 234);
            this.BtnZieldatei.Name = "BtnZieldatei";
            this.BtnZieldatei.Size = new System.Drawing.Size(223, 48);
            this.BtnZieldatei.TabIndex = 5;
            this.BtnZieldatei.Text = "&3.: Zieldatei auswählen";
            this.BtnZieldatei.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnZieldatei.UseVisualStyleBackColor = true;
            this.BtnZieldatei.Click += new System.EventHandler(this.BtnZieldatei_Click);
            // 
            // BtnPaswort
            // 
            this.BtnPaswort.Enabled = false;
            this.BtnPaswort.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnPaswort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPaswort.Location = new System.Drawing.Point(32, 157);
            this.BtnPaswort.Name = "BtnPaswort";
            this.BtnPaswort.Size = new System.Drawing.Size(223, 48);
            this.BtnPaswort.TabIndex = 4;
            this.BtnPaswort.Text = "&2.: Paßwort eingeben";
            this.BtnPaswort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPaswort.UseVisualStyleBackColor = true;
            this.BtnPaswort.Click += new System.EventHandler(this.BtnPaswort_Click);
            // 
            // BtnQuelldatei
            // 
            this.BtnQuelldatei.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnQuelldatei.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuelldatei.Location = new System.Drawing.Point(33, 81);
            this.BtnQuelldatei.Name = "BtnQuelldatei";
            this.BtnQuelldatei.Size = new System.Drawing.Size(223, 48);
            this.BtnQuelldatei.TabIndex = 3;
            this.BtnQuelldatei.Text = "&1.: Quelldatei auswählen";
            this.BtnQuelldatei.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnQuelldatei.UseVisualStyleBackColor = true;
            this.BtnQuelldatei.Click += new System.EventHandler(this.BtnQuelldatei_Click);
            // 
            // DlgQuelldatei
            // 
            this.DlgQuelldatei.Filter = "Textdateien (*.txt)|*.txt";
            // 
            // DlgZieldatei
            // 
            this.DlgZieldatei.Filter = "Textdateien (*.txt)|*.txt";
            // 
            // BtnHilfe
            // 
            this.BtnHilfe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnHilfe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHilfe.Location = new System.Drawing.Point(67, 423);
            this.BtnHilfe.Name = "BtnHilfe";
            this.BtnHilfe.Size = new System.Drawing.Size(223, 48);
            this.BtnHilfe.TabIndex = 6;
            this.BtnHilfe.Text = "&Hilfe";
            this.BtnHilfe.UseVisualStyleBackColor = true;
            this.BtnHilfe.Click += new System.EventHandler(this.BtnHilfe_Click);
            // 
            // BtnInfo
            // 
            this.BtnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInfo.Location = new System.Drawing.Point(341, 423);
            this.BtnInfo.Name = "BtnInfo";
            this.BtnInfo.Size = new System.Drawing.Size(223, 48);
            this.BtnInfo.TabIndex = 7;
            this.BtnInfo.Text = "&Info";
            this.BtnInfo.UseVisualStyleBackColor = true;
            this.BtnInfo.Click += new System.EventHandler(this.BtnInfo_Click);
            // 
            // BtnSalat
            // 
            this.BtnSalat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnSalat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalat.Location = new System.Drawing.Point(67, 22);
            this.BtnSalat.Name = "BtnSalat";
            this.BtnSalat.Size = new System.Drawing.Size(497, 48);
            this.BtnSalat.TabIndex = 0;
            this.BtnSalat.Text = "&Buchstabensalat erzeugen";
            this.BtnSalat.UseVisualStyleBackColor = true;
            this.BtnSalat.Click += new System.EventHandler(this.BtnSalat_Click);
            // 
            // FrmScheishaufen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 497);
            this.Controls.Add(this.BtnSalat);
            this.Controls.Add(this.BtnInfo);
            this.Controls.Add(this.BtnHilfe);
            this.Controls.Add(this.PnlScheishaufen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmScheishaufen";
            this.Text = "Der geflügelte Scheißhaufen";
            this.PnlScheishaufen.ResumeLayout(false);
            this.PnlScheishaufen.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox PnlScheishaufen;
        private System.Windows.Forms.Button BtnZieldatei;
        private System.Windows.Forms.Button BtnPaswort;
        private System.Windows.Forms.Button BtnQuelldatei;
        private System.Windows.Forms.Label LblQuelldatei;
        private System.Windows.Forms.Label LblPaswort;
        private System.Windows.Forms.Label LblZieldatei;
        private System.Windows.Forms.OpenFileDialog DlgQuelldatei;
        private System.Windows.Forms.SaveFileDialog DlgZieldatei;
        private System.Windows.Forms.Button BtnHilfe;
        private System.Windows.Forms.Button BtnInfo;
        private System.Windows.Forms.RadioButton OptEnschlusseln;
        private System.Windows.Forms.RadioButton OptVerschlusseln;
        private System.Windows.Forms.Button BtnSalat;
    }
}

