﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Der_geflügelte_Scheißhaufen
{
    public partial class FrmScheishaufen : Form
    {
        public static int Ask(String Buchstabe)
        {
            /* Die Funktion Ask ordnet jeder Zahl von 1 bis 26 (in diesem konkreten Fall 0 bis 25)
             * eine feste Zahl zu. Hätte man auch mit der Ord-Funktion machen können, aber die scheint
             * es in C# nicht zu geben. Diese Funktion wird aber auch genutzt, um zu kontrollieren,
             * ob das Paßwort oder der Chiffriertext nur Versalien enthält. */
            switch (Buchstabe)
            {
                case "A":
                    return 0;
                case "B":
                    return 1;
                case "C":
                    return 2;
                case "D":
                    return 3;
                case "E":
                    return 4;
                case "F":
                    return 5;
                case "G":
                    return 6;
                case "H":
                    return 7;
                case "I":
                    return 8;
                case "J":
                    return 9;
                case "K":
                    return 10;
                case "L":
                    return 11;
                case "M":
                    return 12;
                case "N":
                    return 13;
                case "O":
                    return 14;
                case "P":
                    return 15;
                case "Q":
                    return 16;
                case "R":
                    return 17;
                case "S":
                    return 18;
                case "T":
                    return 19;
                case "U":
                    return 20;
                case "V":
                    return 21;
                case "W":
                    return 22;
                case "X":
                    return 23;
                case "Y":
                    return 24;
                case "Z":
                    return 25;
                default:
                    return 26;
            }
        }
        
        public FrmScheishaufen()
        {
            InitializeComponent();
        }

        private void BtnPaswort_Click(object sender, EventArgs e)
        {
            int PaswortLange;
            int ZeichenIndex;
            String PaswortDummy;
            
            new FrmPaswort().ShowDialog();
            if (FrmPaswort.Paswortbestatigt == true)
            {
                PaswortDummy = "";
                PaswortLange = FrmPaswort.Paswort.Length;
                for (ZeichenIndex = 0; ZeichenIndex < PaswortLange; ZeichenIndex = ZeichenIndex + 1)
                {
                    PaswortDummy = PaswortDummy + "#";
                }
                LblPaswort.Text = PaswortDummy;
                BtnZieldatei.Enabled = true;
            }
        }

        private void BtnQuelldatei_Click(object sender, EventArgs e)
        {
            DialogResult Eingabe;
            StreamReader Dateicheck;
            String AusleseZeile;
            String Checkbuchstabe;
            int BuchstabenIndex;
            bool Fehler;

            Eingabe = DlgQuelldatei.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                /* Die Quelldatei darf nur Versalien enthalten. */
                Fehler=false;
                Dateicheck = File.OpenText(DlgQuelldatei.FileName);
                while ((AusleseZeile = Dateicheck.ReadLine()) != null)
                {
                    for (BuchstabenIndex = 0; BuchstabenIndex < AusleseZeile.Length; BuchstabenIndex = BuchstabenIndex + 1)
                    {
                        Checkbuchstabe = AusleseZeile.Substring(BuchstabenIndex, 1);
                        if ((Ask(Checkbuchstabe) == 26)&&(Checkbuchstabe != " "))
                        {
                            /* Wenn in dem Text ein Zeichen drin ist, welches nicht
                             * zu den Versalien gezählt wird, dann wird die Datei
                             * nicht anerkannt. Die Restanalyse läuft dann zwar noch
                             * durch, aber das Fehlerflag ist gesetzt. */
                            Fehler = true;
                        }
                    }
                }
                Dateicheck.Dispose();
                if (Fehler == false)
                {
                    LblQuelldatei.Text = DlgQuelldatei.FileName;
                    BtnPaswort.Enabled = true;
                }
                else
                {
                    Eingabe = MessageBox.Show("Die Quelldatei darf nur Großbuchstaben enthalten.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void BtnInfo_Click(object sender, EventArgs e)
        {
            new FrmInfo().ShowDialog();
        }

        private void BtnZieldatei_Click(object sender, EventArgs e)
        {
            StreamReader QuellDatei;
            StreamWriter ZielDatei;
            String AusleseZeile;
            String Parole;
            String SchreibeZeile;
            String Quellbuchstabe;
            String Parolenbuchstabe;
            DialogResult Eingabe;
            char[,] TabulaRecta;
            int BuchstabenIndex;
            int SuchIndex;
            int xIndex;
            int yIndex;

            /* Hier wird zunächst die Zuordnungstabelle generiert. Die Zuordnungstabelle
             * ordnet einen Zielbuchstaben abhängig vom Paßwortbuchstaben und vom
             * Quellbuchstaben zu. */
            TabulaRecta = new char[26,26];
            for (yIndex = 0; yIndex < 26; yIndex = yIndex + 1)
            {
                for (xIndex = 0; xIndex < 26; xIndex = xIndex + 1)
                {
                    TabulaRecta[xIndex, yIndex] = (char)((xIndex + yIndex) % 26 + 65);
                }
            }
            Eingabe = DlgZieldatei.ShowDialog();
            if (Eingabe == DialogResult.OK)
            {
                LblZieldatei.Text = DlgZieldatei.FileName;
                /* Man kann die Quelldatei nicht während der Operation mit der Zieldatei überschreiben. */
                if (LblQuelldatei.Text == LblZieldatei.Text)
                {
                    Eingabe = MessageBox.Show("Die Quelldatei und die Zieldatei sind identisch. Dann kann die Operation nicht durchgeführt werden.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                /* Alle Eingaben sind korrekt gemacht und die Chiffrieroperation kann losgehen. */
                else
                {
                    QuellDatei = File.OpenText(LblQuelldatei.Text);
                    ZielDatei = File.CreateText(LblZieldatei.Text);
                    Parole = FrmPaswort.Paswort;
                    if (OptVerschlusseln.Checked == true)
                    {
                        /* Hier wird verschlüsselt. */
                        while ((AusleseZeile = QuellDatei.ReadLine()) != null)
                        {
                            SchreibeZeile = "";
                            for (BuchstabenIndex = 0; BuchstabenIndex < AusleseZeile.Length; BuchstabenIndex = BuchstabenIndex + 1)
                            {
                                Quellbuchstabe = AusleseZeile.Substring(BuchstabenIndex, 1);
                                /* Man muß unterscheiden, ob ein Versalienbuchstabe kommt oder ein Leerzeichen. */
                                if (Quellbuchstabe != " ")
                                {
                                    Parolenbuchstabe = Parole.Substring(BuchstabenIndex % Parole.Length, 1);
                                    SchreibeZeile = SchreibeZeile + Convert.ToString(TabulaRecta[Ask(Quellbuchstabe), Ask(Parolenbuchstabe)]);
                                }
                                else
                                {
                                    SchreibeZeile = SchreibeZeile + " ";
                                }
                            }
                            ZielDatei.WriteLine(SchreibeZeile);
                        }
                    }
                    else
                    {
                        /* Hier wird entschlüsselt. */
                        while ((AusleseZeile = QuellDatei.ReadLine()) != null)
                        {
                            SchreibeZeile = "";
                            for (BuchstabenIndex = 0; BuchstabenIndex < AusleseZeile.Length; BuchstabenIndex = BuchstabenIndex + 1)
                            {
                                Quellbuchstabe = AusleseZeile.Substring(BuchstabenIndex, 1);
                                if (Quellbuchstabe != " ")
                                {
                                    Parolenbuchstabe = Parole.Substring(BuchstabenIndex % Parole.Length, 1);
                                    for (SuchIndex = 0; SuchIndex < 26; SuchIndex = SuchIndex + 1)
                                    {
                                        /* Der Witz hier ist jetzt, daß man den Paßwortbuchstaben hat (y-Zeile),
                                         * und in dieser Zeile durchlaufen muß, bis man an den verschlüsselten Buchstaben
                                         * anstößt. An dieser Stelle muß man den Spaltenbuchstaben (x-Spalte) der Tabula Recta nehmen
                                         * und hat damit den unverschlüsselten Buchstaben. */
                                        if(TabulaRecta[SuchIndex,Ask(Parolenbuchstabe)] == Convert.ToChar(Quellbuchstabe))
                                        {
                                            SchreibeZeile = SchreibeZeile + Convert.ToString(TabulaRecta[SuchIndex,0]);
                                        }
                                    }
                                }
                                else
                                {
                                    SchreibeZeile = SchreibeZeile + " ";
                                }
                            }
                            ZielDatei.WriteLine(SchreibeZeile);
                        }
                    }
                    QuellDatei.Dispose();
                    ZielDatei.Dispose();
                }
            }
        }

        private void BtnHilfe_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "Hauven.chm");
        }

        private void BtnSalat_Click(object sender, EventArgs e)
        {
            new FrmSalat().ShowDialog();
        }
    }
}
