﻿namespace Der_geflügelte_Scheißhaufen
{
    partial class FrmSalat
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.SpnZeilenanzahl = new System.Windows.Forms.NumericUpDown();
            this.LblZeilenanzahl = new System.Windows.Forms.Label();
            this.SpnBuchstabenanzahl = new System.Windows.Forms.NumericUpDown();
            this.LblBuchstabenanzahl = new System.Windows.Forms.Label();
            this.SpnLangenvarianz = new System.Windows.Forms.NumericUpDown();
            this.LblLangenvarianz = new System.Windows.Forms.Label();
            this.ChkEinzelbuchstabe = new System.Windows.Forms.CheckBox();
            this.LblEinzelbuchstabe = new System.Windows.Forms.Label();
            this.BtnSchliesen = new System.Windows.Forms.Button();
            this.DlgSalat = new System.Windows.Forms.SaveFileDialog();
            this.BtnSalat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SpnZeilenanzahl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpnBuchstabenanzahl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpnLangenvarianz)).BeginInit();
            this.SuspendLayout();
            // 
            // SpnZeilenanzahl
            // 
            this.SpnZeilenanzahl.Location = new System.Drawing.Point(231, 34);
            this.SpnZeilenanzahl.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.SpnZeilenanzahl.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SpnZeilenanzahl.Name = "SpnZeilenanzahl";
            this.SpnZeilenanzahl.Size = new System.Drawing.Size(84, 20);
            this.SpnZeilenanzahl.TabIndex = 0;
            this.SpnZeilenanzahl.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // LblZeilenanzahl
            // 
            this.LblZeilenanzahl.Location = new System.Drawing.Point(32, 36);
            this.LblZeilenanzahl.Name = "LblZeilenanzahl";
            this.LblZeilenanzahl.Size = new System.Drawing.Size(193, 20);
            this.LblZeilenanzahl.TabIndex = 1;
            this.LblZeilenanzahl.Text = "Anzahl der Textzeilen:";
            // 
            // SpnBuchstabenanzahl
            // 
            this.SpnBuchstabenanzahl.Location = new System.Drawing.Point(231, 81);
            this.SpnBuchstabenanzahl.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.SpnBuchstabenanzahl.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.SpnBuchstabenanzahl.Name = "SpnBuchstabenanzahl";
            this.SpnBuchstabenanzahl.Size = new System.Drawing.Size(84, 20);
            this.SpnBuchstabenanzahl.TabIndex = 1;
            this.SpnBuchstabenanzahl.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // LblBuchstabenanzahl
            // 
            this.LblBuchstabenanzahl.Location = new System.Drawing.Point(29, 83);
            this.LblBuchstabenanzahl.Name = "LblBuchstabenanzahl";
            this.LblBuchstabenanzahl.Size = new System.Drawing.Size(196, 20);
            this.LblBuchstabenanzahl.TabIndex = 3;
            this.LblBuchstabenanzahl.Text = "Anzahl der Buchstaben pro Zeile:";
            // 
            // SpnLangenvarianz
            // 
            this.SpnLangenvarianz.Location = new System.Drawing.Point(231, 133);
            this.SpnLangenvarianz.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.SpnLangenvarianz.Name = "SpnLangenvarianz";
            this.SpnLangenvarianz.Size = new System.Drawing.Size(84, 20);
            this.SpnLangenvarianz.TabIndex = 2;
            this.SpnLangenvarianz.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // LblLangenvarianz
            // 
            this.LblLangenvarianz.Location = new System.Drawing.Point(29, 133);
            this.LblLangenvarianz.Name = "LblLangenvarianz";
            this.LblLangenvarianz.Size = new System.Drawing.Size(196, 20);
            this.LblLangenvarianz.TabIndex = 5;
            this.LblLangenvarianz.Text = "Längenvarianz einer Buchstabenzeile:";
            // 
            // ChkEinzelbuchstabe
            // 
            this.ChkEinzelbuchstabe.Location = new System.Drawing.Point(231, 181);
            this.ChkEinzelbuchstabe.Name = "ChkEinzelbuchstabe";
            this.ChkEinzelbuchstabe.Size = new System.Drawing.Size(84, 20);
            this.ChkEinzelbuchstabe.TabIndex = 3;
            this.ChkEinzelbuchstabe.UseVisualStyleBackColor = true;
            // 
            // LblEinzelbuchstabe
            // 
            this.LblEinzelbuchstabe.Location = new System.Drawing.Point(29, 181);
            this.LblEinzelbuchstabe.Name = "LblEinzelbuchstabe";
            this.LblEinzelbuchstabe.Size = new System.Drawing.Size(196, 20);
            this.LblEinzelbuchstabe.TabIndex = 7;
            this.LblEinzelbuchstabe.Text = "Einzelbuchstaben zulässig:";
            // 
            // BtnSchliesen
            // 
            this.BtnSchliesen.Location = new System.Drawing.Point(32, 288);
            this.BtnSchliesen.Name = "BtnSchliesen";
            this.BtnSchliesen.Size = new System.Drawing.Size(282, 42);
            this.BtnSchliesen.TabIndex = 5;
            this.BtnSchliesen.Text = "Schließen";
            this.BtnSchliesen.UseVisualStyleBackColor = true;
            this.BtnSchliesen.Click += new System.EventHandler(this.BtnSchliesen_Click);
            // 
            // DlgSalat
            // 
            this.DlgSalat.Filter = "Textdateien (*.txt)|*.txt";
            // 
            // BtnSalat
            // 
            this.BtnSalat.Location = new System.Drawing.Point(32, 221);
            this.BtnSalat.Name = "BtnSalat";
            this.BtnSalat.Size = new System.Drawing.Size(282, 44);
            this.BtnSalat.TabIndex = 4;
            this.BtnSalat.Text = "Buchstabensalat erzeugen";
            this.BtnSalat.UseVisualStyleBackColor = true;
            this.BtnSalat.Click += new System.EventHandler(this.BtnSalat_Click);
            // 
            // FrmSalat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 365);
            this.ControlBox = false;
            this.Controls.Add(this.BtnSalat);
            this.Controls.Add(this.BtnSchliesen);
            this.Controls.Add(this.LblEinzelbuchstabe);
            this.Controls.Add(this.ChkEinzelbuchstabe);
            this.Controls.Add(this.LblLangenvarianz);
            this.Controls.Add(this.SpnLangenvarianz);
            this.Controls.Add(this.LblBuchstabenanzahl);
            this.Controls.Add(this.SpnBuchstabenanzahl);
            this.Controls.Add(this.LblZeilenanzahl);
            this.Controls.Add(this.SpnZeilenanzahl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSalat";
            this.ShowInTaskbar = false;
            this.Text = "Buchstabensalat erzeugen";
            ((System.ComponentModel.ISupportInitialize)(this.SpnZeilenanzahl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpnBuchstabenanzahl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpnLangenvarianz)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown SpnZeilenanzahl;
        private System.Windows.Forms.Label LblZeilenanzahl;
        private System.Windows.Forms.NumericUpDown SpnBuchstabenanzahl;
        private System.Windows.Forms.Label LblBuchstabenanzahl;
        private System.Windows.Forms.NumericUpDown SpnLangenvarianz;
        private System.Windows.Forms.Label LblLangenvarianz;
        private System.Windows.Forms.CheckBox ChkEinzelbuchstabe;
        private System.Windows.Forms.Label LblEinzelbuchstabe;
        private System.Windows.Forms.Button BtnSchliesen;
        private System.Windows.Forms.SaveFileDialog DlgSalat;
        private System.Windows.Forms.Button BtnSalat;
    }
}