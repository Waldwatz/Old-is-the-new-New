﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Der_geflügelte_Scheißhaufen
{   
    public partial class FrmPaswort : Form
    {
        public static Boolean Paswortbestatigt;
        public static String Paswort = "";

        public FrmPaswort()
        {
            InitializeComponent();
            Paswortbestatigt = false;
            EdtPaswort.Text = Paswort;
        }

        private void ChkMaskieren_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkMaskieren.Checked == false)
            {
                EdtPaswort.UseSystemPasswordChar = false;
            }
            else
            {
                EdtPaswort.UseSystemPasswordChar = true;
            }
        }

        private void BtnAbbrechen_Click(object sender, EventArgs e)
        {
            /* Paswortbestatigt dient dazu, zu schauen, ob der Dummystring im Hauptfenster aktualisiert werden muß. */
            Paswortbestatigt = false;
            this.Close();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            DialogResult Eingabe;
            int BuchstabenIndex;
            bool Leerstelle;
            
            /* Das Paßwort darf keine Leerstelle, Sonderzeichen, Umlaute oder Minuskeln enthalten. */
            Leerstelle=false;
            for (BuchstabenIndex = 0; BuchstabenIndex < EdtPaswort.Text.Length; BuchstabenIndex = BuchstabenIndex + 1)
            {
                if (FrmScheishaufen.Ask(EdtPaswort.Text.Substring(BuchstabenIndex, 1)) == 26)
                {
                    Leerstelle = true;
                }
            }
            /* Wenn das Paßwort also in Ordnung ist, kann man es umsetzen. */
            if (Leerstelle == false)
            {
                Paswortbestatigt = true;
                Paswort = EdtPaswort.Text;
                this.Close();
            }
            else
            {
                Eingabe = MessageBox.Show("Das Paßwort darf keine Leerstellen enthalten und muß aus Großbuchstaben von A bis Z bestehen. Umlaute sind nicht zulässig.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }
    }
}
