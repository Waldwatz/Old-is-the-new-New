﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Der_geflügelte_Scheißhaufen
{
    public partial class FrmSalat : Form
    {
        public static String Zeichen(int Ziffer)
        {
            /* C# scheint keine Chr-Funktion so wie Basic zu haben.
             * Also wird sie eben schnell selbst geproggt. */
            switch (Ziffer)
            {
                case 1:
                    return "A";
                case 2:
                    return "B";
                case 3:
                    return "C";
                case 4:
                    return "D";
                case 5:
                    return "E";
                case 6:
                    return "F";
                case 7:
                    return "G";
                case 8:
                    return "H";
                case 9:
                    return "I";
                case 10:
                    return "J";
                case 11:
                    return "K";
                case 12:
                    return "L";
                case 13:
                    return "M";
                case 14:
                    return "N";
                case 15:
                    return "O";
                case 16:
                    return "P";
                case 17:
                    return "Q";
                case 18:
                    return "R";
                case 19:
                    return "S";
                case 20:
                    return "T";
                case 21:
                    return "U";
                case 22:
                    return "V";
                case 23:
                    return "W";
                case 24:
                    return "X";
                case 25:
                    return "Y";
                case 26:
                    return "Z";
                case 27:
                    return " ";
                default:
                    return " ";
            }
        }
        
        public FrmSalat()
        {
            InitializeComponent();
        }

        private void BtnSchliesen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnSalat_Click(object sender, EventArgs e)
        {
            Random Zufall = new Random();
            int Zufallszahl;
            int Zahlvorher;
            int Zweivorher;
            StreamWriter SalatDatei;
            String SchreibeZeile;
            DialogResult Eingabe;
            int ZeilenAnzahl;
            int ZeilenIndex;
            int BuchstabenAnzahl;
            int BuchstabenIndex;
            int Langenvarianz;
            int Zeilenabweichung;
                        
            Eingabe = DlgSalat.ShowDialog();
            ZeilenAnzahl = (int) SpnZeilenanzahl.Value;
            BuchstabenAnzahl = (int) SpnBuchstabenanzahl.Value;
            Langenvarianz = (int) SpnLangenvarianz.Value;
            // Damit man nicht doppelte Leerzeilen hat oder Einzelbuchstaben wählbar macht,
            // gibt es die Variable Zahlvorher. Initialisiert wird diese mit Null, damit
            // der Erstvergleich immer negativ ausfällt.
            Zahlvorher = 0;
            Zweivorher=0;
            if (Eingabe == DialogResult.OK)
            {
                SalatDatei=File.CreateText(DlgSalat.FileName);
                for (ZeilenIndex = 0; ZeilenIndex < ZeilenAnzahl; ZeilenIndex = ZeilenIndex + 1)
                {
                    SchreibeZeile = "";
                    // Für jede neue Zeile wird eine neue Längenvarianz ermittelt.
                    Zeilenabweichung = Zufall.Next(1, Langenvarianz) - (Langenvarianz/2);
                    for (BuchstabenIndex = 0; BuchstabenIndex < BuchstabenAnzahl+Zeilenabweichung; BuchstabenIndex = BuchstabenIndex + 1)
                    {
                        // In dieser Schleife werden erst mal hintereinander liegende
                        // Leerzeichen rausgefiltert.
                        do
                        {
                            Zufallszahl = Zufall.Next(1, 32);
                        } while ((Zufallszahl > 26) && (Zahlvorher > 26));
                        // Wenn der User das wünscht, kann man auch Einzelbuchstaben
                        // eliminieren.
                        while ((Zweivorher > 26) && (Zufallszahl > 26) && (ChkEinzelbuchstabe.Checked == false))
                        {
                            Zufallszahl = Zufall.Next(1, 32);
                        }
                        SchreibeZeile = String.Concat(SchreibeZeile,Zeichen(Zufallszahl));
                        Zweivorher = Zahlvorher;
                        Zahlvorher = Zufallszahl;
                    }
                    /* Leider ist es so, daß der Algorithmus keine Leerzeichen am
                     * Anfang und am Ende erwischt. Desweiteren kann es noch Einzelzeichen
                     * am Anfang und am Ende geben. Das wird mit den nächsten Anweisungen
                     * bereinigt.*/
                    SchreibeZeile = SchreibeZeile.Trim();
                    /* Desweiteren kan der oben stehende Algorithmus keine Leerzeichen an
                     * der zweiten oder der vorletzten Stelle detektieren. Deshalb müssen
                     * diese Leerstellen nochmal gesondert abgefragt werden.*/
                    if((SchreibeZeile.Substring(1,1) == " ") && (ChkEinzelbuchstabe.Checked == false))
                    {
                        SchreibeZeile = SchreibeZeile.Insert(1, Zeichen(Zufall.Next(1,26)));
                    }
                    if ((SchreibeZeile.Substring(SchreibeZeile.Length - 2, 1) == " ") && (ChkEinzelbuchstabe.Checked == false))
                    {
                        SchreibeZeile = SchreibeZeile.Insert(SchreibeZeile.Length - 1, Zeichen(Zufall.Next(1, 26)));
                    }
                    SalatDatei.WriteLine(SchreibeZeile);
                }
                SalatDatei.Dispose();
            }
        }
    }
}
