﻿namespace Der_geflügelte_Scheißhaufen
{
    partial class FrmPaswort
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.EdtPaswort = new System.Windows.Forms.TextBox();
            this.ChkMaskieren = new System.Windows.Forms.CheckBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.BtnAbbrechen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EdtPaswort
            // 
            this.EdtPaswort.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.EdtPaswort.Location = new System.Drawing.Point(35, 29);
            this.EdtPaswort.Name = "EdtPaswort";
            this.EdtPaswort.Size = new System.Drawing.Size(353, 20);
            this.EdtPaswort.TabIndex = 0;
            // 
            // ChkMaskieren
            // 
            this.ChkMaskieren.AutoSize = true;
            this.ChkMaskieren.Location = new System.Drawing.Point(35, 68);
            this.ChkMaskieren.Name = "ChkMaskieren";
            this.ChkMaskieren.Size = new System.Drawing.Size(152, 17);
            this.ChkMaskieren.TabIndex = 1;
            this.ChkMaskieren.Text = "Maskierte Paßworteingabe";
            this.ChkMaskieren.UseVisualStyleBackColor = true;
            this.ChkMaskieren.CheckedChanged += new System.EventHandler(this.ChkMaskieren_CheckedChanged);
            // 
            // BtnOk
            // 
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Location = new System.Drawing.Point(35, 113);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(163, 32);
            this.BtnOk.TabIndex = 2;
            this.BtnOk.Text = "OK";
            this.BtnOk.UseVisualStyleBackColor = true;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // BtnAbbrechen
            // 
            this.BtnAbbrechen.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnAbbrechen.Location = new System.Drawing.Point(225, 113);
            this.BtnAbbrechen.Name = "BtnAbbrechen";
            this.BtnAbbrechen.Size = new System.Drawing.Size(163, 32);
            this.BtnAbbrechen.TabIndex = 3;
            this.BtnAbbrechen.Text = "Abbrechen";
            this.BtnAbbrechen.UseVisualStyleBackColor = true;
            this.BtnAbbrechen.Click += new System.EventHandler(this.BtnAbbrechen_Click);
            // 
            // FrmPaswort
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BtnAbbrechen;
            this.ClientSize = new System.Drawing.Size(425, 181);
            this.ControlBox = false;
            this.Controls.Add(this.BtnAbbrechen);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.ChkMaskieren);
            this.Controls.Add(this.EdtPaswort);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPaswort";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Paßworteingabe";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox EdtPaswort;
        private System.Windows.Forms.CheckBox ChkMaskieren;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Button BtnAbbrechen;
    }
}